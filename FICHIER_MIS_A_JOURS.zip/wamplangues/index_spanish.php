<?php
// 3.2.0 - txtProjects
// 3.2.1 - defaultDBMS - HelpMySQLMariaDB
// 3.2.5 - documentation-of ajouté pour les langues le nécessitant
// pour le Français est identique à documentation
// 3.2.6 - txtNoHosts
// 3.2.8 - phpNotExists - txtProjectsLink - phpExtensions - phpVersionsUse
// 3.3.0 - txtPathNoSlash
// 3.3.2 - txtSlashEnd

$langues = array(
	'langue' => 'Español',
	'locale' => 'spanish',
	'titreHtml' => 'Página de inicio de WAMPSERVER',
	'titreConf' => 'Configuración del servidor',
	'versa' => 'Versión de Apache:',
	'doca2.2' => 'httpd.apache.org/docs/2.2/es/',
	'doca2.4' => 'httpd.apache.org/docs/2.4/es/',
	'versp' => 'Versión de PHP:',
	'server' => 'Software del servidor:',
	'documentation' => 'Documentación',
	'documentation-of' => 'Documentación',
	'docp' => 'www.php.net/manual/es/',
	'versm' => 'Versión de MySQL:',
	'docm' => 'dev.mysql.com/doc/index.html',
	'versmaria' => 'Versión de MariaDB: ',
	'docmaria' => 'mariadb.com/kb/en/mariadb/documentation',
	'phpExt' => 'Extensiones cargadas: ',
	'titrePage' => 'Herramientas',
	'txtProjet' => 'Sus proyectos',
	'txtServerName' => 'El nombre del servidor %s tiene un error de sintaxis en el archivo %s',
	'txtDocRoot' => 'El nombre del servidor %s utilizar ruta del documento %s reservado para el servidor local',
	'txtTLDdev' => 'El nombre del servidor %s utilizar TLD %s, que está monopolizado por los navegadores web. Utilice otro TLD (por ejempo .test)',
	'txtNoHosts' => 'El nombre del servidor %s no está definido en el archivo de hosts',
	'txtServerNameIp' => 'La IP %s del nombre del servidor %s no es válida en el archivo %s',
	'txtVhostNotClean' => 'El archivo %s no se ha limpiado. Ejemplo de hospedador virtual como: dummy-host.example.com',
	'txtNoProjet' => 'Aún no hay proyectos<br/>Para crear un nuevo proyecto, debe cree un directorio en \www\.',
	'txtProjectsLink' =>'Para esto, debes hacer clic derecho en el icono de Wampserver, Configuración de wampserver, en la pestaña, Precaución. Esto es sólo para expertos..., Permitir enlaces en la página de inicio de proyectos...',
	'txtProjects' => 'Estas son sus carpetas en %s<br />Para utilizarlas como enlace http, debes declararlas como hospedador virtual',
	'txtAlias' => 'Sus alias',
	'txtNoAlias' => 'Aún no hay alias<br />Para crear una nuevo, use el menú de WAMPSERVER',
	'txtVhost' => 'Su servidor virtual',
	'txtNoVhost' => 'Aún no hay hospedador virtual. Agregue uno para cada proyecto en el archivo wamp/bin/apache/apache%s/conf/extra/httpd-vhosts.conf',
	'txtNoIncVhost' => 'Descomentar o agregar <i>Include conf/extra/httpd-vhosts.conf</i> en el archivo wamp/bin/apache/apache%s/conf/httpd.conf',
	'txtNoVhostFile' => 'El archivo: %s no existe',
	'txtNoPath' => 'La ruta %s para %s no existe (archivo %s)',
	'txtSlashEnd' => 'La ruta %s para %s termina con una barra (Archivo %s)',
	'txtPathNoSlash' => 'La ruta %s para %s no termina con una barra inclinada /',
	'txtNotWritable' => 'El archivo %s es de solo lectura',
	'txtNbNotEqual' => 'El número de %s no coincide con el número de %s en el archivo %s',
	'txtAddVhost' => 'Agregar un hospedador virtual',
	'txtCorrected' => 'Algunos errores de los servidores locales podrán ser corregidos',
	'txtPortNumber' => 'El número de puerto para %s no tiene el valor correcto o no es el mismo en el archivo %s',
	'forum' => 'Foro de Wampserver',
	'forumLink' => 'http://forum.wampserver.com/list.php?2',
	'portUsed' => 'Puerto definido para Apache ',
	'mysqlportUsed' => 'Puerto definido para MySQL ',
	'mariaportUsed' => 'Puerto definido para MariaDB ',
	'defaultDBMS' => 'SGBD predeterminado',
	'phpNotExists' => 'La versión de PHP no existe',
	'HelpMySQLMariaDB' => 'Cómo usar MySQL y/o MariaDB?<br>Qué es un DBMS predeterminado?<br>Cómo cambiar el DBMS predeterminado?<br>Vaya a la ayuda relacionada, luego haga clic derecho el el botón del icono de Wampmanager -> Ayuda -> MariaDB - MySQL',
	'nolocalhost' => 'Es una mala idea aggregar localhost en la url de lanzamiento de proyectos. Es mejor definir el hospedador virtual en el archivo<br/>wamp/bin/apache/apache%s/conf/extra/httpd-vhosts.conf<br/> y no agregar localhost en la url',
	'phpExtensions' => 'Extensiones PHP cargadas',
	'phpVersionsUse' => 'Uso de versiones de PHP',
	);
?>