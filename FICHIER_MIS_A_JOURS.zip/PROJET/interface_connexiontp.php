

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>Connexion</h1>

    <?php if (isset($_SESSION['login'])): ?>
        <div class="welcome">
            <p>Bonjour <?php echo htmlspecialchars($_SESSION['login']); ?> !</p>
            <a class="btn logout-btn" href="deconnexion.php">Se déconnecter</a>
        </div>
    <?php else: ?>
        <form action="connection.php" method="post">
            <label for="login">Login :</label>
            <input type="text" id="login" name="login" required>

            <label for="password">Mot de passe :</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Se connecter" class="btn">
        </form>
    <?php endif; ?>
</div>

</body>
</html>


