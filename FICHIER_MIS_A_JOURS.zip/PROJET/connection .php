<?php
session_start();

$validLogin = "admin";
$validPassword = "1234";

$login = $_POST['login'] ?? '';
$password = $_POST['password'] ?? '';

if ($login === $validLogin && $password === $validPassword) {
    $_SESSION['login'] = $login;
    header("Location: interface_connexion.php");
    exit();
} else {
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <div class="error-box">
        <h1>Erreur de connexion</h1>
        <p>Login ou mot de passe incorrect.</p>
        <a class="btn" href="interface_connexiontp.php">Réessayer</a>
    </div>
</div>

</body>
</html>
<?php
}
?>
