<?php 

    // Adapter le chemin vers .env
    // Le fichier .env ne devrait pas se trouver dans le répertoire de votre site web.
    // Vous pouvez le placer dans C:/msys64, avant le dossier /www/
    $env = parse_ini_file(__DIR__ . "/.env");    
    if (!$env) {
        die("Fichier .env manquant ou illisible.");
    }

    $db_host = $env['DB_HOST'];
    $db_name = $env['DB_NAME'];
    $db_user = $env['DB_USER'];
    $db_pass = $env['DB_PASS'];
        
    try {
    	//Data Source Name
    	$dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4;port=3306"
        $pdo = new PDO(
            $dsn,
            $env['DB_USER'],
            $env['DB_PASS']
        );
        $dsn = 'mysql:host=localhost;port=3306;dbname=bdd';
    } catch (PDOException $e) {
        die("Erreur de connexion à la base de données. Veuillez contacter l'administrateur.");
    }
?>
