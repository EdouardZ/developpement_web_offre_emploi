<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Offres d\'Emploi</title>
</head>
<body>
    <p>
        <?php echo "Hello world" ; ?>
    </p>
</body>
</html>
