<?php
$page_title = "Page de connexion";
include 'header.php';
?>

<p>Voici la page de connexion</p>

<?php include 'footer.php'; ?>
