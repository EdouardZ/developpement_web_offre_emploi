<?php
$page_title = "Page1";
include 'header.php';
?>
<div>
    <p>Voici la page 1</p>
</div>
<div style="margin:1em;">
    <p>
        <?php
            $x = 5;
            $y = 12;
            echo  "Combien font $x + $y ?";
        ?>
    </p>
    <form method="post" action="">
        <label for="reponse">Votre réponse :</label>
        <input type="number" id="reponse" name="reponse" required>
        <button type="submit">Valider</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $reponseUtilisateur = $_POST['reponse']; 

        $bonneReponse = $x + $y;
        if ($reponseUtilisateur == $bonneReponse) {
            echo "<p style='color:green'>Bravo, $reponseUtilisateur est la bonne réponse !</p>";
        } else {
            echo "<p style='color:red'>Désolé, la bonne réponse était $bonneReponse.</p>";
        }
    }
    ?>
</div>

<div>
    <p>param1 : <?php echo isset($_GET["param1"]) ? htmlspecialchars($_GET["param1"]) : "non défini"; ?></p>
</div>

<?php include 'footer.php'; ?>
