<!DOCTYPE html>
<html lang="fr">
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
    <title>GESTION DES OFFRES D'EMPLOI</title>
</head>
<body>
    <p>
        <?php echo "hello world" ; ?>
</P>
</body>
</html>