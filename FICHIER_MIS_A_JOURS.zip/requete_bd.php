<?php 
    // Ajoutez cette ligne à chaque fois que vous souhaitez vous connecter à la base de données.
    // Adapter le chemin vers connexion_bd.php si besoin
    require_once __DIR__ . '/connexion_bd.php'; 

    $stmt = $pdo->prepare("SELECT * FROM utilisateurs");
    $stmt->execute([]);
    $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);
    echo($utilisateur["username"]);

    $stmt = $pdo->prepare("SELECT ? FROM utilisateurs WHERE ?");
    $stmt->execute(["username", 3]);
    $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);
    echo($utilisateur["username"]);
?>