
<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Connexion</title>
        <meta charset="utf-8">
    </head>
   <body>
        <h1>Voici la page de connexion</h1>
        <p>En entrant votre nom d'utilisateur et votre mot de passe, les utilisateurs inscrits peuvent accéder au site de gestion des offres d'emploi.
        </p>
        <p>
            <i>Pas encore inscrit ?</i>
            <a href='interface_inscription.php'>M'inscrire</a>
        </p>
    <?php
     //Du code PHP
    ?>
    </body>
</html>