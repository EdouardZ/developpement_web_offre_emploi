<?php
    // les lignes suivantes au
    // début de vos codes PHP permettent d’afficher les erreurs
    // PHP sur la page web. Attention, ces lignes ne doivent pas
    // être présentes dans un environnement de production
    ini_set('display_errors', 1) ;
    ini_set('display_startup_errors', 1) ;
    error_reporting(E_ALL) ;

    // On affiche d'abord la page interface_inscription.php
    include("interface_inscription.php");

    // Ajoutez cette ligne à chaque fois que vous souhaitez vous connecter à la base de données.
    // Adapter le chemin vers connexion_bd.php si besoin
    require_once __DIR__ . '/connexion_bd.php'; // Alternative :   include("connexion_bd.php");

    $stmt = $pdo->prepare("SELECT * FROM Utilisateur");
    $stmt->execute([]);
    $utilisateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo("Voici le nom de tous les utilisateurs : </br>");
    foreach($utilisateurs as $u){
        echo($u["nom"] . "</br>");

    }

    echo("_____________</br>");
    $stmt = $pdo->prepare("SELECT nom, mail FROM Utilisateur WHERE id=?");
    $id = 3;
    $stmt->execute([ $id]);
    $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);
    echo("L'utilisateur dont l'identifiant recherché est ". $id . 
    " est : " . $utilisateur["nom"] .
    "</br>Son adresse email est : " . $utilisateur["mail"]);
?>