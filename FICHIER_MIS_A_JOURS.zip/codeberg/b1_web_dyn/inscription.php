<?php
    // les lignes suivantes au
    // début de vos codes PHP permettent d’afficher les erreurs
    // PHP sur la page web. Attention, ces lignes ne doivent pas
    // être présentes dans un environnement de production
    ini_set('display_errors', 1) ;
    ini_set('display_startup_errors', 1) ;
    error_reporting(E_ALL) ;

    // Ajoutez cette ligne à chaque fois que vous souhaitez vous connecter à la base de données.
    // Adapter le chemin vers connexion_bd.php si besoin
    require_once __DIR__ . '/connexion_bd.php'; // Alternative :   include("connexion_bd.php");

    try{
        // Requête INSERT avec des paramètres nommés (pour éviter les injections SQL)
        $sql = "INSERT INTO Utilisateur (nom, mot_de_passe, mail) VALUES (:nom, :mot_de_passe, :mail)";
        $stmt = $pdo->prepare($sql);

        // Données à insérer
        // Les données issues du formulaire sont stockées dans la variable $_POST.
        // Les clés correspondantes sont les id des balises input du formulaire.
        $data = [
            'nom' => $_POST["login"],
            'mot_de_passe' => $_POST["password"],
            'mail' => $_POST["mail"]
        ];

        // Exécution de la requête
        $stmt->execute($data);

        // Récupération de l'ID de la dernière ligne insérée 
        // (notre table Utilisateur a un id auto-incrémenté)
        $lastInsertId = $pdo->lastInsertId();
        echo "Ligne insérée avec succès ! ID : $lastInsertId";
        echo "<p>Redirection en cours... 
            <i>(redirection avec JavaScript)</i></p>";
        // Redirection avec JS
        echo '<script>window.location.href = "connexion.php";</script>';
        // Redirection PHP : header("Location: connexion.php");
        exit();

    } catch (PDOException $e) {
        // Affichage des erreurs PDO (violation de contrainte, syntaxe SQL invalide...)
        die("Erreur lors de l'insertion : " . $e->getMessage());
        
    }
?>