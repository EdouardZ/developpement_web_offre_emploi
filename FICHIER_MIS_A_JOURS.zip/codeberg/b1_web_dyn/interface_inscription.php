<form action="inscription.php" method="post">
    <label for="login">Nom :</label>
    <input type="text" id="login" name="login" required><br><br>
    <label for="mail">Mail :</label>
    <input type="email" id="mail" name="mail" required><br><br>
    <label for="password">Mot de passe :</label>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="S'inscrire">
</form>
<form action="voir_utilisateurs.php" method="get">
    <input type="submit" value="Montrer les utilisateurs existants">
</form>

