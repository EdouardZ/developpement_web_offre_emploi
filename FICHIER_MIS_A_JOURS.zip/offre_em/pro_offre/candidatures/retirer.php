<?php
// candidatures/retirer.php
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$base        = '/pro_offre';
$currentUser = $_SESSION['user'] ?? null;
if (!$currentUser) { header("Location: $base/auth/login.php"); exit; }

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: $base/offres/index.php"); exit; }

$pdo->prepare('DELETE FROM candidatures WHERE id_utilisateur = ? AND id_offre = ?')
    ->execute([$currentUser['id'], $id]);

header("Location: $base/offres/view.php?id=$id&withdrawn=1");
exit;
