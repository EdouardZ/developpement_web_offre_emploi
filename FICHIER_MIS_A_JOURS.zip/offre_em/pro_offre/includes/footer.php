</main>

<footer class="footer">
    JobBoard &copy; <?= date('Y') ?> — Projet B1 ECE Bordeaux
</footer>

<script src="/pro_offre/assets/js/main.js"></script>
</body>
</html>
