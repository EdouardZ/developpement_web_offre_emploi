/* main.js — Toast, Modal confirm, Force mot de passe */

/* ---- TOAST ---- */
function showToast(message, type = 'success') {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    const icons = { success: '✓', error: '✕', info: 'ℹ' };
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `<span>${icons[type]||'✓'}</span><span>${message}</span>`;
    document.body.appendChild(toast);
    requestAnimationFrame(() => requestAnimationFrame(() => toast.classList.add('toast--show')));
    setTimeout(() => { toast.classList.remove('toast--show'); setTimeout(() => toast.remove(), 350); }, 3200);
}

/* ---- MODAL CONFIRM ---- */
function confirmAction(message, onConfirm, danger = true) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
        <div class="modal-box">
            <h3>${danger ? '⚠️ Confirmation' : 'Confirmation'}</h3>
            <p>${message}</p>
            <div class="modal-actions">
                <button class="btn btn-ghost" id="modal-cancel">Annuler</button>
                <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="modal-confirm">Confirmer</button>
            </div>
        </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => requestAnimationFrame(() => overlay.classList.add('modal--open')));
    const close = () => { overlay.classList.remove('modal--open'); setTimeout(() => overlay.remove(), 250); };
    overlay.querySelector('#modal-cancel').addEventListener('click', close);
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    overlay.querySelector('#modal-confirm').addEventListener('click', () => { close(); onConfirm(); });
}

document.addEventListener('DOMContentLoaded', () => {

    /* Intercepte les liens data-confirm */
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', e => {
            e.preventDefault();
            confirmAction(
                el.getAttribute('data-confirm'),
                () => { window.location.href = el.getAttribute('href'); },
                el.getAttribute('data-danger') !== 'false'
            );
        });
    });

    /* Force mot de passe */
    const pw  = document.getElementById('password');
    const bar = document.querySelector('.pw-strength__bar');
    if (pw && bar) {
        pw.addEventListener('input', () => {
            const v = pw.value;
            let s = 0;
            if (v.length >= 8) s++;
            if (/[A-Z]/.test(v)) s++;
            if (/[0-9]/.test(v)) s++;
            if (/[^A-Za-z0-9]/.test(v)) s++;
            bar.style.width = ['0%','25%','50%','75%','100%'][s];
            bar.style.background = ['','#EF4444','#F59E0B','#3B82F6','#22C55E'][s];
        });
    }

    /* Auto-hide alertes succès */
    document.querySelectorAll('.alert-success').forEach(el => {
        setTimeout(() => { el.style.transition='opacity .5s'; el.style.opacity='0'; setTimeout(()=>el.remove(),500); }, 4000);
    });

    /* Toasts depuis URL */
    const p = new URLSearchParams(window.location.search);
    if (p.get('deleted')   === '1') showToast('Offre supprimée.', 'success');
    if (p.get('updated')   === '1') showToast('Offre mise à jour.', 'success');
    if (p.get('applied')   === '1') showToast('Candidature envoyée !', 'success');
    if (p.get('withdrawn') === '1') showToast('Candidature retirée.', 'info');
});
