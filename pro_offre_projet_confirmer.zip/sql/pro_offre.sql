-- =====================================================
-- ECE JobBoard — Script SQL
-- Projet B1 ECE Bordeaux 2025-2026
-- Importer dans phpMyAdmin avant de lancer le site
-- =====================================================

CREATE DATABASE IF NOT EXISTS pro_offre
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE pro_offre;

-- Table utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    nom          VARCHAR(100)  NOT NULL,
    email        VARCHAR(150)  NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255)  NOT NULL,   -- hashé avec password_hash()
    cv_texte     TEXT,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table offres
CREATE TABLE IF NOT EXISTS offres (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    titre        VARCHAR(200)  NOT NULL,
    description  TEXT          NOT NULL,
    salaire      DECIMAL(10,2) DEFAULT NULL,
    lieu         VARCHAR(150)  DEFAULT NULL,
    type_contrat ENUM('CDI','CDD','Freelance','Stage','Intérim') NOT NULL,
    id_createur  INT           NOT NULL,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_offre_createur
        FOREIGN KEY (id_createur) REFERENCES utilisateurs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table candidatures (liaison N-N)
CREATE TABLE IF NOT EXISTS candidatures (
    id_utilisateur INT       NOT NULL,
    id_offre       INT       NOT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_utilisateur, id_offre),
    CONSTRAINT fk_cand_user  FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    CONSTRAINT fk_cand_offre FOREIGN KEY (id_offre)       REFERENCES offres(id)       ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- DONNÉES DE TEST
-- Mot de passe de tous : password123
-- =====================================================
INSERT INTO utilisateurs (nom, email, mot_de_passe, cv_texte) VALUES
('Alice Martin', 'alice@exemple.com',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'Développeuse PHP/Laravel, 3 ans d''expérience. Vue.js, MySQL, TDD.'),
('Bob Dupont', 'bob@exemple.com',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'Admin systèmes Linux. CCNA, VMware, Zabbix.'),
('Clara Nguyen', 'clara@exemple.com',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'Étudiante BUT Informatique. Python, HTML/CSS, SQL.');

INSERT INTO offres (titre, description, salaire, lieu, type_contrat, id_createur) VALUES
('Développeur PHP — Alternance',
 'Agence web cherche alternant développeur PHP/Laravel.

Missions :
- Développement de fonctionnalités PHP
- Intégration APIs RESTful
- Tests unitaires

Profil : étudiant BUT/Licence Informatique',
 1800.00, 'Bordeaux', 'CDI', 1),

('Admin Systèmes Linux — CDI',
 'DSI recherche admin sys expérimenté.

Missions :
- Administration serveurs Debian/Ubuntu
- Supervision réseau Zabbix
- Automatisation Ansible

Profil : 2 ans exp. min.',
 2900.00, 'Toulouse', 'CDI', 2),

('Stage Développeur Web — 6 mois',
 'Startup SaaS cherche stagiaire.

Stack : React, Node.js, PostgreSQL.
Gratification légale.',
 600.00, 'Paris — Télétravail', 'Stage', 1),

('Technicien Support N2 — CDD',
 'Support technique N2 pour grand compte bancaire.
ServiceNow, réseau, postes de travail.',
 2100.00, 'Lyon', 'CDD', 2),

('Développeur Freelance — Mission React',
 'Refonte UI en React + TypeScript.
TJM selon profil. Full remote possible.',
 NULL, 'Bordeaux ou remote', 'Freelance', 1);

INSERT INTO candidatures (id_utilisateur, id_offre) VALUES
(3, 1), (2, 3), (3, 2);
