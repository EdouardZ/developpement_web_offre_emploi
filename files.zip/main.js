/* =====================================================
   JOBBOARD — main.js
   Fonctions : Toast, Modal confirmation, Force MDP
   ===================================================== */

/* ---------- TOAST ---------- */
function showToast(message, type = 'success') {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const icons = { success: '✓', error: '✕', info: 'ℹ' };
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `<span>${icons[type] || '✓'}</span><span>${message}</span>`;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        requestAnimationFrame(() => toast.classList.add('toast--show'));
    });

    setTimeout(() => {
        toast.classList.remove('toast--show');
        setTimeout(() => toast.remove(), 350);
    }, 3200);
}

/* ---------- MODAL CONFIRMATION ---------- */
function confirmAction(message, onConfirm, danger = true) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
        <div class="modal-box">
            <h3>${danger ? '⚠️ Confirmation' : 'Confirmation'}</h3>
            <p>${message}</p>
            <div class="modal-actions">
                <button class="btn btn-ghost" id="modal-cancel">Annuler</button>
                <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="modal-confirm">
                    Confirmer
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    requestAnimationFrame(() => {
        requestAnimationFrame(() => overlay.classList.add('modal--open'));
    });

    const close = () => {
        overlay.classList.remove('modal--open');
        setTimeout(() => overlay.remove(), 250);
    };

    overlay.querySelector('#modal-cancel').addEventListener('click', close);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('#modal-confirm').addEventListener('click', () => {
        close();
        onConfirm();
    });
}

/* ---------- REMPLACEMENT DES CONFIRM() ---------- */
document.addEventListener('DOMContentLoaded', () => {

    // Intercepte tous les liens de suppression avec data-confirm
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            const href  = el.getAttribute('href');
            const msg   = el.getAttribute('data-confirm');
            const danger = el.getAttribute('data-danger') !== 'false';
            confirmAction(msg, () => { window.location.href = href; }, danger);
        });
    });

    /* ---------- FORCE MOT DE PASSE ---------- */
    const pwInput = document.getElementById('password');
    const bar     = document.querySelector('.pw-strength__bar');

    if (pwInput && bar) {
        pwInput.addEventListener('input', () => {
            const pw = pwInput.value;
            let score = 0;
            if (pw.length >= 8)          score++;
            if (/[A-Z]/.test(pw))        score++;
            if (/[0-9]/.test(pw))        score++;
            if (/[^A-Za-z0-9]/.test(pw)) score++;

            const colors = ['', '#EF4444', '#F59E0B', '#3B82F6', '#22C55E'];
            const widths = ['0%', '25%', '50%', '75%', '100%'];
            bar.style.width      = widths[score];
            bar.style.background = colors[score];
        });
    }

    /* ---------- AUTO-HIDE ALERTS ---------- */
    document.querySelectorAll('.alert-success').forEach(el => {
        setTimeout(() => {
            el.style.transition = 'opacity .5s';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 500);
        }, 4000);
    });

    /* ---------- TOAST DEPUIS URL PARAM ---------- */
    const params = new URLSearchParams(window.location.search);
    if (params.get('deleted')  === '1') showToast('Offre supprimée avec succès.', 'success');
    if (params.get('updated')  === '1') showToast('Offre mise à jour.', 'success');
    if (params.get('applied')  === '1') showToast('Candidature envoyée !', 'success');
    if (params.get('withdrawn') === '1') showToast('Candidature retirée.', 'info');
});
