<?php
// candidatures/postuler.php
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$base        = '/jobboard';
$currentUser = $_SESSION['user'] ?? null;
if (!$currentUser) { header("Location: $base/auth/login.php"); exit; }

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: $base/offres/index.php"); exit; }

$stmt = $pdo->prepare('SELECT id_createur FROM offres WHERE id = ?');
$stmt->execute([$id]);
$offre = $stmt->fetch();
if (!$offre || $offre['id_createur'] == $currentUser['id']) {
    header("Location: $base/offres/view.php?id=$id"); exit;
}

// INSERT IGNORE évite les doublons sans erreur
$pdo->prepare('INSERT IGNORE INTO candidatures (id_utilisateur, id_offre) VALUES (?, ?)')
    ->execute([$currentUser['id'], $id]);

header("Location: $base/offres/view.php?id=$id&applied=1");
exit;
