<?php
// =====================================================
// config/db.php — Connexion PDO à la base de données
// =====================================================
// ⚠️  Modifier DB_USER et DB_PASS selon votre config XAMPP

define('DB_HOST', 'localhost');
define('DB_NAME', 'jobboard');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // En production : logger l'erreur, ne pas l'afficher
    die('<div style="font-family:sans-serif;padding:2rem;color:#B91C1C;background:#FEE2E2;border-radius:8px;margin:2rem">
        <strong>Erreur de connexion à la base de données.</strong><br>
        Vérifiez que XAMPP est démarré et que la base "jobboard" existe.
    </div>');
}
