<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) session_start();
$base = '/jobboard';
$currentUser = $_SESSION['user'] ?? null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — JobBoard' : 'JobBoard' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <a href="<?= $base ?>/index.php" class="nav-brand">
        <span class="brand-dot"></span>JobBoard
    </a>

    <div class="nav-links">
        <a href="<?= $base ?>/offres/index.php" class="nav-link">Offres</a>

        <?php if ($currentUser): ?>
            <a href="<?= $base ?>/offres/create.php" class="nav-link">Publier</a>
            <a href="<?= $base ?>/index.php?tab=mes-offres" class="nav-link">Tableau de bord</a>
            <div class="nav-user">
                <div class="nav-avatar"><?= strtoupper(substr($currentUser['nom'], 0, 1)) ?></div>
                <span class="nav-name"><?= htmlspecialchars($currentUser['nom']) ?></span>
                <a href="<?= $base ?>/auth/logout.php" class="btn btn-ghost btn-sm">Déconnexion</a>
            </div>
        <?php else: ?>
            <a href="<?= $base ?>/auth/login.php"    class="btn btn-ghost   btn-sm">Connexion</a>
            <a href="<?= $base ?>/auth/register.php" class="btn btn-primary btn-sm">S'inscrire</a>
        <?php endif; ?>
    </div>
</nav>

<main class="main-content">
