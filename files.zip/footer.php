</main>

<footer class="footer">
    JobBoard &copy; <?= date('Y') ?> — Projet B1 ECE Bordeaux
</footer>

<script src="/jobboard/assets/js/main.js"></script>
</body>
</html>
