# 📋 DIRECTIVES — JobBoard B1 ECE Bordeaux

## Structure des fichiers

```
jobboard/
├── index.php               ← Tableau de bord (mes offres + mes candidatures)
├── config/
│   └── db.php              ← Connexion PDO à la BDD
├── includes/
│   ├── header.php          ← Navbar + <head> HTML
│   └── footer.php          ← Footer + chargement JS
├── auth/
│   ├── login.php           ← Connexion (password_verify)
│   ├── register.php        ← Inscription (password_hash)
│   └── logout.php          ← Déconnexion (session_destroy)
├── offres/
│   ├── index.php           ← Liste toutes les offres + filtres/tri (BONUS)
│   ├── view.php            ← Détail d'une offre + liste candidats
│   ├── create.php          ← Créer une offre
│   ├── edit.php            ← Modifier une offre
│   └── delete.php          ← Supprimer une offre
├── candidatures/
│   ├── postuler.php        ← Postuler à une offre
│   └── retirer.php         ← Retirer sa candidature
├── assets/
│   ├── css/style.css       ← Design inspiré Side.co (violet, blanc)
│   └── js/main.js          ← Toast, modal confirm, force mot de passe
└── sql/
    └── jobboard.sql        ← Script SQL complet + données de test
```

---

## ✅ ÉTAPE 1 — Installer XAMPP

1. Télécharger XAMPP : https://www.apachefriends.org/
2. Lancer **XAMPP Control Panel**
3. Démarrer **Apache** et **MySQL**

---

## ✅ ÉTAPE 2 — Copier le projet

1. Copier le dossier `jobboard/` dans :
   - Windows : `C:\xampp\htdocs\jobboard\`
   - Mac/Linux : `/Applications/XAMPP/htdocs/jobboard/`

---

## ✅ ÉTAPE 3 — Importer la base de données

1. Ouvrir phpMyAdmin : http://localhost/phpmyadmin
2. Cliquer sur **"Importer"**
3. Sélectionner le fichier `sql/jobboard.sql`
4. Cliquer **"Exécuter"**

> La base `jobboard` et les 3 tables sont créées automatiquement.

---

## ✅ ÉTAPE 4 — Vérifier la config BDD

Ouvrir `config/db.php` et vérifier les valeurs :
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'jobboard');
define('DB_USER', 'root');
define('DB_PASS', '');      // vide par défaut sur XAMPP
```

---

## ✅ ÉTAPE 5 — Lancer le site

Ouvrir : http://localhost/jobboard/offres/index.php

---

## 🧪 Comptes de test

| Nom          | Email              | Mot de passe |
|--------------|--------------------|--------------|
| Alice Martin | alice@exemple.com  | password123  |
| Bob Dupont   | bob@exemple.com    | password123  |
| Clara Nguyen | clara@exemple.com  | password123  |

---

## 📊 Grille d'évaluation — Ce qui est couvert

| Critère                    | Fichier(s) concerné(s)                           | ✓ |
|----------------------------|--------------------------------------------------|---|
| Authentification sécurisée | auth/register.php, auth/login.php                | ✓ |
| Mots de passe hashés       | password_hash() + password_verify()              | ✓ |
| GET — Affichage offres     | offres/index.php, offres/view.php                | ✓ |
| GET — Voir les candidats   | offres/view.php (section créateur)               | ✓ |
| PUT — Créer une offre      | offres/create.php                                | ✓ |
| PUT — Inscrire utilisateur | auth/register.php                                | ✓ |
| DELETE — Supprimer offre   | offres/delete.php (vérif. propriétaire)          | ✓ |
| UPDATE — Candidater        | candidatures/postuler.php + retirer.php          | ✓ |
| UPDATE — Modifier offre    | offres/edit.php                                  | ✓ |
| UX/UI + messages d'erreur  | style.css + main.js (toast, modal)               | ✓ |
| BONUS Filtres              | offres/index.php (?lieu= &type_contrat=)         | ✓ |
| BONUS Tri salaire          | offres/index.php (?tri=salaire_asc/desc)         | ✓ |

---

## 🎤 Pour la soutenance (19 mai)

### Indicateurs de performance à mesurer

1. **Sécurité** → https://developer.mozilla.org/en-US/observatory
   - Entrer l'URL de votre site déployé
   - Viser un score > C

2. **Rapidité** → https://pagespeed.web.dev/
   - Entrer l'URL
   - Présenter le score Performance (mobile + desktop)

3. **Sobriété** → https://www.ecoindex.fr/
   - Entrer l'URL
   - Présenter la note et le poids de la page

### Architecture à présenter

- **Stack** : PHP 8+ | MySQL | HTML5 | CSS3 | JavaScript
- **BDD** : 3 tables (utilisateurs, offres, candidatures)
- **Sécurité** : PDO + requêtes préparées, password_hash, session_regenerate_id
- **Pas de framework** : 100% natif

---

## ⚠️ Points importants à retenir pour la soutenance

- Les mots de passe sont hashés avec **bcrypt** (`PASSWORD_DEFAULT`)
- Toutes les requêtes SQL utilisent des **requêtes préparées** → protection contre les injections SQL
- La clé primaire composite `(id_utilisateur, id_offre)` dans candidatures **empêche les doublons**
- `ON DELETE CASCADE` : supprimer un utilisateur ou une offre supprime automatiquement les candidatures liées
- `session_regenerate_id(true)` après connexion → protection contre le vol de session
