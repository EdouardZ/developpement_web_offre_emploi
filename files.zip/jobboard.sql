-- =====================================================
-- JOBBOARD — Script SQL complet
-- Projet B1 ECE Bordeaux 2025-2026
-- Importer dans phpMyAdmin AVANT de lancer le site
-- =====================================================

CREATE DATABASE IF NOT EXISTS jobboard
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE jobboard;

-- =====================================================
-- TABLE : utilisateurs
-- =====================================================
CREATE TABLE IF NOT EXISTS utilisateurs (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    nom          VARCHAR(100)  NOT NULL,
    email        VARCHAR(150)  NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255)  NOT NULL,    -- TOUJOURS hashé avec password_hash()
    cv_texte     TEXT,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE : offres
-- =====================================================
CREATE TABLE IF NOT EXISTS offres (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    titre        VARCHAR(200)  NOT NULL,
    description  TEXT          NOT NULL,
    salaire      DECIMAL(10,2) DEFAULT NULL,
    lieu         VARCHAR(150)  DEFAULT NULL,
    type_contrat ENUM('CDI','CDD','Freelance','Stage','Intérim') NOT NULL,
    id_createur  INT           NOT NULL,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_offre_createur
        FOREIGN KEY (id_createur) REFERENCES utilisateurs(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE : candidatures  (table de liaison N-N)
-- =====================================================
CREATE TABLE IF NOT EXISTS candidatures (
    id_utilisateur INT       NOT NULL,
    id_offre       INT       NOT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_utilisateur, id_offre),    -- clé composite → pas de doublon possible
    CONSTRAINT fk_cand_user  FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    CONSTRAINT fk_cand_offre FOREIGN KEY (id_offre)       REFERENCES offres(id)       ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- DONNÉES DE TEST
-- Mot de passe de tous les comptes : password123
-- Hash généré avec password_hash('password123', PASSWORD_DEFAULT)
-- =====================================================

INSERT INTO utilisateurs (nom, email, mot_de_passe, cv_texte) VALUES
(
    'Alice Martin',
    'alice@exemple.com',
    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'Développeuse web — 3 ans d''expérience. PHP, Laravel, Vue.js, MySQL. Passionnée par les architectures propres et le TDD.'
),
(
    'Bob Dupont',
    'bob@exemple.com',
    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'Technicien réseaux et systèmes. Certifié Cisco CCNA. Administration Linux, virtualisation VMware, monitoring Zabbix.'
),
(
    'Clara Nguyen',
    'clara@exemple.com',
    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'Étudiante BUT Informatique 2e année. Python, HTML/CSS, SQL, bases de données relationnelles.'
);

INSERT INTO offres (titre, description, salaire, lieu, type_contrat, id_createur) VALUES
(
    'Développeur PHP / Laravel — Alternance',
    'Rejoignez notre agence web pour développer des applications métier sur mesure.

Missions :
- Développement de fonctionnalités PHP/Laravel
- Intégration d''APIs RESTful
- Rédaction de tests unitaires
- Participation aux revues de code

Profil :
- Étudiant BUT Informatique, Licence ou Mastère
- Connaissance de PHP et SQL
- Autonomie et curiosité

Rythme : 3j entreprise / 2j école',
    1800.00, 'Bordeaux', 'CDI', 1
),
(
    'Administrateur Systèmes Linux — CDI',
    'Nous cherchons un admin sys expérimenté pour notre DSI.

Missions :
- Administration serveurs Debian/Ubuntu
- Supervision réseau (Zabbix, Nagios)
- Automatisation Ansible et Bash

Profil : 2 ans d''expérience min., maîtrise Linux production',
    2900.00, 'Toulouse', 'CDI', 2
),
(
    'Stage Développeur Web — 6 mois',
    'Startup SaaS cherche stagiaire développeur web.

Stack : React, Node.js, PostgreSQL, Docker.

Missions :
- Contribution front-end React
- Mise en place de composants réutilisables
- Documentation technique

Convention obligatoire. Gratification légale.',
    600.00, 'Paris — Télétravail partiel', 'Stage', 1
),
(
    'Technicien Support N2 — CDD 6 mois',
    'Mission de support technique N2 pour grand compte bancaire.

Responsabilités :
- Diagnostic incidents réseau / postes de travail
- Escalade vers N3
- Tickets ITSM (ServiceNow)

Profil : BTS SIO ou équivalent',
    2100.00, 'Lyon', 'CDD', 2
),
(
    'Développeur Freelance — Mission React',
    'Mission freelance 3 mois pour refonte interface client.

Détail :
- Refonte UI React + TypeScript
- Intégration Figma → code
- Livraison par sprints de 2 semaines

TJM selon profil. Début dès que possible.',
    NULL, 'Bordeaux ou full remote', 'Freelance', 1
);

INSERT INTO candidatures (id_utilisateur, id_offre) VALUES
(3, 1),
(2, 3),
(3, 2);
