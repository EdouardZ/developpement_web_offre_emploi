<?php
// index.php — Tableau de bord utilisateur
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$base        = '/jobboard';
$currentUser = $_SESSION['user'] ?? null;

// Si non connecté → rediriger vers la liste des offres
if (!$currentUser) {
    header("Location: $base/offres/index.php"); exit;
}

$tab = $_GET['tab'] ?? 'mes-offres';

// Mes offres créées
$s1 = $pdo->prepare(
    'SELECT o.*, (SELECT COUNT(*) FROM candidatures c WHERE c.id_offre = o.id) AS nb_candidats
     FROM offres o WHERE o.id_createur = ? ORDER BY o.id DESC'
);
$s1->execute([$currentUser['id']]);
$mesOffres = $s1->fetchAll();

// Mes candidatures
$s2 = $pdo->prepare(
    'SELECT o.*, u.nom AS nom_createur
     FROM offres o
     JOIN candidatures c ON c.id_offre = o.id
     JOIN utilisateurs u ON u.id = o.id_createur
     WHERE c.id_utilisateur = ? ORDER BY o.id DESC'
);
$s2->execute([$currentUser['id']]);
$mesCandidatures = $s2->fetchAll();

$pageTitle = 'Tableau de bord';
require_once __DIR__ . '/includes/header.php';
?>

<div class="dashboard">

    <div class="dashboard__header">
        <div class="dashboard__welcome">
            <div class="dashboard__avatar"><?= strtoupper(substr($currentUser['nom'],0,1)) ?></div>
            <div>
                <h1>Bonjour, <?= htmlspecialchars($currentUser['nom']) ?> 👋</h1>
                <p class="page-subtitle"><?= htmlspecialchars($currentUser['email']) ?></p>
            </div>
        </div>
        <a href="<?= $base ?>/offres/create.php" class="btn btn-primary">+ Publier une offre</a>
    </div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card">
            <span class="stat-number"><?= count($mesOffres) ?></span>
            <span class="stat-label">Offre<?= count($mesOffres)>1?'s':'' ?> publiée<?= count($mesOffres)>1?'s':'' ?></span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?= array_sum(array_column($mesOffres,'nb_candidats')) ?></span>
            <span class="stat-label">Candidature<?= array_sum(array_column($mesOffres,'nb_candidats'))>1?'s':'' ?> reçue<?= array_sum(array_column($mesOffres,'nb_candidats'))>1?'s':'' ?></span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?= count($mesCandidatures) ?></span>
            <span class="stat-label">Candidature<?= count($mesCandidatures)>1?'s':'' ?> envoyée<?= count($mesCandidatures)>1?'s':'' ?></span>
        </div>
    </div>

    <!-- Onglets -->
    <div class="tabs">
        <a href="?tab=mes-offres"   class="tab <?= $tab==='mes-offres'   ? 'tab--active':'' ?>">Mes offres</a>
        <a href="?tab=candidatures" class="tab <?= $tab==='candidatures' ? 'tab--active':'' ?>">Mes candidatures</a>
    </div>

    <!-- Mes offres -->
    <?php if ($tab === 'mes-offres'): ?>
        <?php if (empty($mesOffres)): ?>
            <div class="empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5.586a1 1 0 0 1 .707.293l5.414 5.414a1 1 0 0 1 .293.707V19a2 2 0 0 1-2 2z"/></svg>
                <p>Vous n'avez pas encore publié d'offre.</p>
                <a href="<?= $base ?>/offres/create.php" class="btn btn-primary">Publier ma première offre</a>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Titre</th><th>Type</th><th>Lieu</th>
                            <th>Salaire</th><th>Candidats</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($mesOffres as $o):
                            $slug = strtolower(str_replace(['é','è','ê','î'],['e','e','e','i'],$o['type_contrat']));
                        ?>
                            <tr>
                                <td><a href="<?= $base ?>/offres/view.php?id=<?= $o['id'] ?>"><?= htmlspecialchars($o['titre']) ?></a></td>
                                <td><span class="badge badge--<?= $slug ?>"><?= $o['type_contrat'] ?></span></td>
                                <td><?= htmlspecialchars($o['lieu'] ?? '—') ?></td>
                                <td><?= $o['salaire'] ? number_format($o['salaire'],0,',',' ').' €' : '—' ?></td>
                                <td>
                                    <a href="<?= $base ?>/offres/view.php?id=<?= $o['id'] ?>" class="candidats-count">
                                        <?= $o['nb_candidats'] ?> candidat<?= $o['nb_candidats']>1?'s':'' ?>
                                    </a>
                                </td>
                                <td class="table-actions">
                                    <a href="<?= $base ?>/offres/edit.php?id=<?= $o['id'] ?>" class="btn btn-ghost btn-xs">Modifier</a>
                                    <a href="<?= $base ?>/offres/delete.php?id=<?= $o['id'] ?>"
                                       class="btn btn-danger btn-xs"
                                       data-confirm="Supprimer cette offre ?" data-danger="true">Supprimer</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    <!-- Mes candidatures -->
    <?php else: ?>
        <?php if (empty($mesCandidatures)): ?>
            <div class="empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 13.255A23.931 23.931 0 0 1 12 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2m4 6h.01M5 20h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"/></svg>
                <p>Vous n'avez pas encore postulé à des offres.</p>
                <a href="<?= $base ?>/offres/index.php" class="btn btn-primary">Explorer les offres</a>
            </div>
        <?php else: ?>
            <div class="offres-grid">
                <?php foreach ($mesCandidatures as $o):
                    $slug = strtolower(str_replace(['é','è','ê','î'],['e','e','e','i'],$o['type_contrat']));
                ?>
                    <div class="offre-card offre-card--applied">
                        <div class="offre-card__header">
                            <div style="display:flex;gap:.4rem">
                                <span class="badge badge--<?= $slug ?>"><?= $o['type_contrat'] ?></span>
                                <span class="badge badge--applied">Candidaté ✓</span>
                            </div>
                        </div>
                        <h2 class="offre-card__titre">
                            <a href="<?= $base ?>/offres/view.php?id=<?= $o['id'] ?>"><?= htmlspecialchars($o['titre']) ?></a>
                        </h2>
                        <p class="offre-card__entreprise"><?= htmlspecialchars($o['nom_createur']) ?></p>
                        <div class="offre-card__meta">
                            <?php if ($o['lieu']): ?><span class="meta-item">📍 <?= htmlspecialchars($o['lieu']) ?></span><?php endif; ?>
                            <?php if ($o['salaire']): ?><span class="meta-item">💶 <?= number_format($o['salaire'],0,',',' ') ?> €</span><?php endif; ?>
                        </div>
                        <div class="offre-card__actions">
                            <a href="<?= $base ?>/offres/view.php?id=<?= $o['id'] ?>" class="btn btn-ghost btn-sm">Voir l'offre</a>
                            <a href="<?= $base ?>/candidatures/retirer.php?id=<?= $o['id'] ?>"
                               class="btn btn-ghost btn-sm"
                               data-confirm="Retirer votre candidature ?" data-danger="false">Retirer</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
