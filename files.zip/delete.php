<?php
// offres/delete.php
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$base        = '/jobboard';
$currentUser = $_SESSION['user'] ?? null;
if (!$currentUser) { header("Location: $base/auth/login.php"); exit; }

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: $base/offres/index.php"); exit; }

// Vérifie que l'offre appartient bien à cet utilisateur avant de supprimer
$stmt = $pdo->prepare('SELECT id FROM offres WHERE id = ? AND id_createur = ?');
$stmt->execute([$id, $currentUser['id']]);
if (!$stmt->fetch()) { header("Location: $base/offres/index.php"); exit; }

// Suppression — les candidatures partent en CASCADE
$pdo->prepare('DELETE FROM offres WHERE id = ? AND id_createur = ?')
    ->execute([$id, $currentUser['id']]);

header("Location: $base/index.php?deleted=1");
exit;
